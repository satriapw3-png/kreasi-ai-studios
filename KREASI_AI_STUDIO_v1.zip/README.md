# KREASI AI STUDIO v1

Starter Android project for building a debug APK with GitHub Actions.

## Build versions

- JDK: 17
- Gradle: 8.14
- Android Gradle Plugin: 8.11.1
- Kotlin Gradle Plugin: 2.2.21
- Android compile SDK: 35
- Android Build Tools: 35.0.0
- Minimum Android version: API 23 (Android 6.0)

## GitHub Actions build

The workflow is included at `.github/workflows/build-apk.yml`. It supports either of these repository layouts:

1. Upload the contents of this ZIP to the repository root (so `settings.gradle.kts` is at the root); or
2. Upload this ZIP file itself to the repository root. The workflow will find and extract it automatically.

Then open **Actions**, select **Build KREASI AI STUDIO APK**, and choose **Run workflow**. When the run finishes successfully, open that run and download the `KREASI-AI-STUDIO-v1-APK` artifact.

The result is a debug APK named `app-debug.apk`. This project is still a starter app; it does not yet connect to a live AI service.
