package com.kreasi.aistudio

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(245, 247, 252))
        }

        val title = TextView(this).apply {
            text = "KREASI AI STUDIO"
            textSize = 26f
            setTextColor(Color.rgb(36, 48, 85))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Tempat memulai ide kreatifmu"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 28)
        }
        val info = TextView(this).apply {
            text = "Versi awal berhasil dibuka. Fitur AI dapat ditambahkan setelah kebutuhan aplikasinya ditentukan."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val button = Button(this).apply {
            text = "Mulai"
            setOnClickListener {
                info.text = "Selamat datang di KREASI AI STUDIO!"
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(info)
        root.addView(button)
        setContentView(root)
    }
}
